import { useEffect, useRef } from 'react';

interface SoundManagerProps {
  enabled: boolean;
}

const SoundManager = ({ enabled }: SoundManagerProps) => {
  const ambientRef = useRef<HTMLAudioElement | null>(null);
  const clickRef = useRef<HTMLAudioElement | null>(null);
  const hoverRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    // Create audio elements
    ambientRef.current = new Audio();
    ambientRef.current.loop = true;
    ambientRef.current.volume = 0.1;

    clickRef.current = new Audio();
    clickRef.current.volume = 0.3;

    hoverRef.current = new Audio();
    hoverRef.current.volume = 0.1;

    // Generate ambient sound using Web Audio API
    if (enabled && typeof window !== 'undefined') {
      try {
        const audioContext = new (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)();
        
        // Create oscillator for ambient hum
        const oscillator = audioContext.createOscillator();
        const gainNode = audioContext.createGain();
        
        oscillator.type = 'sine';
        oscillator.frequency.setValueAtTime(60, audioContext.currentTime);
        
        gainNode.gain.setValueAtTime(0.02, audioContext.currentTime);
        
        oscillator.connect(gainNode);
        gainNode.connect(audioContext.destination);
        
        oscillator.start();

        return () => {
          oscillator.stop();
          audioContext.close();
        };
      } catch (e) {
        console.log('Web Audio API not supported');
      }
    }
  }, [enabled]);

  // Add click sound listeners
  useEffect(() => {
    if (!enabled) return;

    const handleClick = () => {
      if (clickRef.current) {
        clickRef.current.currentTime = 0;
        clickRef.current.play().catch(() => {});
      }
    };

    const handleMouseEnter = () => {
      if (hoverRef.current) {
        hoverRef.current.currentTime = 0;
        hoverRef.current.play().catch(() => {});
      }
    };

    // Add listeners to interactive elements
    const buttons = document.querySelectorAll('button, a');
    buttons.forEach((btn) => {
      btn.addEventListener('click', handleClick);
      btn.addEventListener('mouseenter', handleMouseEnter);
    });

    return () => {
      buttons.forEach((btn) => {
        btn.removeEventListener('click', handleClick);
        btn.removeEventListener('mouseenter', handleMouseEnter);
      });
    };
  }, [enabled]);

  return null; // This is a logic-only component
};

export default SoundManager;
